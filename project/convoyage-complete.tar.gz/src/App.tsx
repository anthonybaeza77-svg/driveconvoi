import { useState } from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import QuoteForm from './components/QuoteForm';
import BlogList from './components/BlogList';
import Footer from './components/Footer';

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'blog'>('home');

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />

      {currentPage === 'home' ? (
        <>
          <Hero />
          <section id="quote-form" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <QuoteForm />
          </section>
        </>
      ) : (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
              Notre Blog
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Actualités, conseils et informations sur le convoyage de véhicules
            </p>
          </div>
          <BlogList />
        </section>
      )}

      <Footer />
    </div>
  );
}

export default App;
