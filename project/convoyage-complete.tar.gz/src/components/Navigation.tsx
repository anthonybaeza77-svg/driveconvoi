
interface NavigationProps {
  currentPage: 'home' | 'blog';
  onNavigate: (page: 'home' | 'blog') => void;
}

export default function Navigation({ currentPage, onNavigate }: NavigationProps) {
  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center space-x-3 group"
          >
            <img src="/CaptureLogoVoiture.png" alt="Convoy-Auto Logo" className="h-14 w-auto" />
            <span className="text-xl font-bold text-slate-900 group-hover:text-slate-700 transition-colors">
              Convoy-Auto
            </span>
          </button>

          <div className="flex space-x-1">
            <button
              onClick={() => onNavigate('home')}
              className={`px-6 py-2 rounded-lg font-medium transition-all ${
                currentPage === 'home'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Accueil
            </button>
            <button
              onClick={() => onNavigate('blog')}
              className={`px-6 py-2 rounded-lg font-medium transition-all ${
                currentPage === 'blog'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Blog
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
